public class Integralelements2 {
    public static void main(String[] args) {
        System.out.printf("Inherent elements of the sequence ");

        for (int a = 90; a > (-1); a = a - 5) {
            System.out.printf(", " + a);
        }
        System.out.printf(".");
    }
}
