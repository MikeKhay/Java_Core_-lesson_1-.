public class Elements55_1 {

        public static void main(String[] args) {
            System.out.printf("Cilivity of 55 oll elements ");

            for (int a = 1; a < (55*2); a = a + 2) {
                System.out.printf(", " + a);
            }
            System.out.printf(".");
        }
    }

