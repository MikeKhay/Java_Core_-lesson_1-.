public class Truefolse3 {
    static boolean dividerByTwo(int a){
        return (a%2==0);
    }
    public static void main(String[] args){
        System.out.printf("The number of guys? ");
        System.out.println( dividerByTwo(7) );
    }
}
