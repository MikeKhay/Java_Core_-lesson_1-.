public class WhileLoop {

    public static void main(String[] args) {

        int c = 1;
        do {
            System.out.println("count up " + c);
            c++;

        } while (c < 5);


        int i = 10;
        while (c > 0) {
            System.out.println("count down " + i);
            c--;
        }
    }
}
